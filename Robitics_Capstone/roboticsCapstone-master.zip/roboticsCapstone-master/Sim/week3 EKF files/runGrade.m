clear all
close all
grade
